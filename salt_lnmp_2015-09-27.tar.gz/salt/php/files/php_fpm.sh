#!/bin/bash
yum install -y  zlib-devel openssl openssl-devel gcc gcc-c++ autoconf automake zlib-devel libxml2-devel make ncurses-devel libtool cmake mhash mcrypt libjpeg-devel libpng-devel db4-devel libXpm-devel freetype-devel openldap-devel openssl-devel libcurl-devel bison re2c libmcrypt-devel

cp /usr/lib64/libldap* /usr/lib/
